package life.majiang.community.enums;

/**
 * Created by codedrinker on 2019/9/6.
 */
public enum AdPosEnum {
    NAV, SIDE, FOOTER, HEADER
}
