package life.majiang.community.enums;

/**
 * Created by codedrinker on 2019/8/18.
 */
public enum SortEnum {
    HOT,
    HOT30,
    HOT7,
    NO,
    NEW;
}
